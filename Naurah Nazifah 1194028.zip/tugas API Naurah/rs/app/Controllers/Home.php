<?php

namespace App\Controllers;

class Home extends BaseController
{
	public function index()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://dekontaminasi.com/api/id/covid19/hospitals');
		$body = $response->getBody();
		$data['d'] = json_decode($body);
		return view('home', $data);
	}

	public function detailberita()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/detail/2021/01/28/balan-wonderworld-preview');
		$body = $response->getBody();
		// dd($body);
		$d = json_decode($body);
		$data['d'] = $d->results;
		return view('detailberita', $data);
	}

	public function games()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/games?page=1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('games', $data);
	}

	public function esport()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/games/e-sport?page1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('esport', $data);
	}

	public function news()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/games/news?page1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('news', $data);
	}

	public function lazytalk()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/games/lazy-talk?page1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('lazy-talk', $data);
	}

	public function pc()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/games/pc?page1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('pc', $data);
	}

	public function review()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/games/review?page1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('review', $data);
	}

	public function technews()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/tech?page1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('tech-news', $data);
	}

	public function techsetup()
	{
		$client = \Config\Services::curlrequest();
		$response = $client->request('GET', 'https://the-lazy-media-api.vercel.app/api/tech/setup?page1');
		$body = $response->getBody();
		// dd($body);
		$data['d']  = json_decode($body);
		return view('tech-setup', $data);
	}
}
