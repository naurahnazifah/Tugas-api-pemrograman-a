<?= $this->extend('layout'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="row my-5 text-center">
        <div class="col">
            <!-- <h2 class="text-secondary">Daftar Film Bioskop</h2> -->
            <h2 class="text-secondary">Data Rumah Sakit Rujukan COVID-19 di Indonesia</h2>
        </div>
    </div>
    <div class="row">
        <?php
        foreach ($d as $r) {

            // foreach ($d->result->hasil as $r) {
            //     echo '<div class="col-md-3">
            //     <div class="card mb-2">
            //         <img class="card-img-top" src="' . $r->img . '" alt="Card image cap">
            //         <div class="card-body">
            //             <h5 class="card-title">' . substr($r->title, 0, 15) . '</h5>
            //             <a href="' . $r->url . '" target="_blank" class="btn btn-primary">Jadwal Film</a>
            //         </div>
            //     </div>
            // </div>';
            // }
        ?>
            <div class="col-12">
                <div class="card mb-3">
                    <div class="card-body">
                        <h5><?= $r->name; ?></h5>
                        <p><?= $r->address; ?><br><?= $r->region; ?><br><?= $r->province; ?><br><?= $r->phone; ?></p>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <nav aria-label="Page navigation example">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                    <li class="page-item"><a class="page-link" href="#">1</a></li>
                    <li class="page-item"><a class="page-link" href="#">2</a></li>
                    <li class="page-item"><a class="page-link" href="#">3</a></li>
                    <li class="page-item"><a class="page-link" href="#">Next</a></li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>