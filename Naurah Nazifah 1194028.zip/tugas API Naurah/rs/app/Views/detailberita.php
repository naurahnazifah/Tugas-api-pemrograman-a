<?= $this->extend('layout'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="row my-5 text-center">
        <div class="col">
            <!-- <h2 class="text-secondary">Daftar Film Bioskop</h2> -->
            <h2 class="text-secondary">Detail</h2>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <img src="<?= $d->thumb; ?>" alt="<?= $d->title; ?>" class="mb-3" width="50%">
            <h3><?= $d->title; ?></h3>
            <p>Author : <?= $d->author; ?> <br>
                Date : <?= $d->date; ?> </p>
            Content<br>
            <?php foreach ($d->content as $c) { ?>
                <?= $c ?>
            <?php } ?>
        </div>
    </div>
</div>
<?= $this->endSection(); ?>