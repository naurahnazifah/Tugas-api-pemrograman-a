<?= $this->extend('layout'); ?>
<?= $this->section('content'); ?>
<div class="container">
    <div class="row my-5 text-center">
        <div class="col">
            <!-- <h2 class="text-secondary">Daftar Film Bioskop</h2> -->
            <h2 class="text-secondary">Tech Setup</h2>
        </div>
    </div>
    <div class="row">
        <?php foreach ($d as $a) { ?>
            <div class="col-md-3">
                <div class="card mb-2">
                    <img class="card-img-top" src="<?= $a->thumb; ?>" alt="Card image cap">
                    <div class="card-body">
                        <h5 class="card-title"><?= substr($a->title, 0, 15) ?></h5>
                        <small><?= $a->author; ?></small>
                    </div>
                </div>
            </div>
        <?php } ?>
    </div>
</div>
<?= $this->endSection(); ?>